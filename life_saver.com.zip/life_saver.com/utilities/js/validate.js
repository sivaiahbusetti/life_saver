function validateForm()
{
  			var fname = document.getElementById("fname").value;
			var lname = document.getElementById("lname").value;
			var blood = document.getElementById("blood");
			var age = document.getElementById("age").value;
			var gen = document.getElementById("gen");
			var houseno = document.getElementById("houseno").value;
			var city = document.getElementById("city").value;
			var district = document.getElementById("district").value;
			var pincode = document.getElementById("pincode").value;
			var state = document.getElementById("state").value;
			var country = document.getElementById("country").value;
			var mail = document.getElementById("mail").value;
			var mobnum = document.getElementById("mobnum").value;
			






  			if (fname == ""||fname =="null") 
			{
    				alert("First Name can't be blank");
    				return false;
  			}
			if (lname == ""||lname =="null") 
			{
    				alert("Last Name can't be blank");
    				return false;
  			}
			if (blood.selectedIndex == 0)
			{
				alert("Select your blood group");
    				return false;
			}
			if (age == ""||age =="null") 
			{
    				alert("Age can't be blank");
    				return false;
  			}
			if (gen.selectedIndex == 0)
			{
				alert("Select your Gender");
    				return false;
			}
  			if (houseno == ""||houseno =="null") 
			{
    				alert("House Number can't be blank");
    				return false;
  			}
			
  			if (city == ""||city =="null") 
			{
    				alert("City can't be blank");
    				return false;
  			}
			
  			if (district == ""||district =="null") 
			{
    				alert("District can't be blank");
    				return false;
  			}
			*/
  			if (pincode == ""||pincode.length==5) 
			{
    				alert("Pincode can't be blank");
    				return false;
  			}
			
  			if (state == ""||state =="null") 
			{
    				alert("State can't be blank");
    				return false;
  			}
			if (country == ""||country =="null") 
			{
    				alert("Country can't be blank");
    				return false;
  			}
  			
			
			
			if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.mail.value))
  			{
    				return (true)
  			}
			else
			{
    				alert("You have entered an invalid email address!")
    				return (false)
			}
			
			/*if (mobnum == ""||mobnum =="null") 
			{
    				alert("Mobile Number can't be blank");
    				return false;
  			}*/



			
}