<div class="page-wrapper">
	<?php $this->view($header);?>
	<div class="main-content">
		<?php $this->view($banner);?>
		<?php $this->view($content);?>
	</div>
	<?php $this->view($footer);?>
</div>