<section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <h1 class="text-capitalize mb-5 text-lg">For Funds Donation</h1>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="contact-form-wrap section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-title text-center">
                    <h2 class="text-md mb-2">Fundraing</h2>
                    <div class="divider mx-auto my-4"></div>
                    <p class="mb-5">Raise Funds For Your Transplant Surgery From 30+ Lakh Donors .</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                
			<form name="myForm" class="contact__form " method="post" action="<?php echo base_url();?>confirmation" onsubmit="return funds()">
                 <!-- form message -->
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-success contact__msg" style="display: none" role="alert">
                                Your message was sent successfully.
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="name" type="text" class="form-control" placeholder="Full Name" >
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <input name="trid" id="trid" type="text" class="form-control" placeholder="Transaction ID" >
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="mail" id="mail" type="email" class="form-control" placeholder="Your Email Address">
                            </div>
                        </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="mnum" id="mnum" type="number" class="form-control" placeholder="Your Phone Number">
                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                       
                        <button type="submit" class="btn btn-main btn-round-full" value="submit">SUBMIT</button>
                    </div>
                </form>
                <script type="text/javascript">
					function funds()
					{
						var fname = document.getElementById("name").value;
						var trid = document.getElementById("trid").value;
						var mail = document.getElementById("mail").value;
						var mnum = document.getElementById("mnum").value;
						

						if(fname==""||fname=="null")
						{
							alert("Name can't be blank");
		          			return false;
						}
						if(trid==""||trid=="null")
						{
							alert("Transaction ID can't be blank");
		          			return false;
						}
						if (mnum == ""||mnum.length ==10) 
          				{
          					alert("Phone Number can't be blank");
          					return false;
          				}
						if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.mail.value))
          				{
          					return (true)
          				}
          				else
          				{
          					alert("You have entered an invalid email address!");
          					return false;
          				}
					}
                </script>
            </div>
        </div>
    </div>
</section>
<section class="section contact-info pb-0">
    <div class="container">
         <div class="row">
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="fa fa-bank"></i>
                    <h5>Bank transfer</h5>
                     A/C NO:123456789012<br>IFSC CODE:abcde12345
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="fa fa-angle-right"></i>
                    <h5>UPI ID</h5>
                     acdsx@okicici<br>fddsgfd@okicici
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="fa fa-money"></i>
                    <h5>Cash Donation</h5>
                     Tirupati,<br>Andhra Pradesh and India
                </div>
            </div>
        </div>
    </div>
</section>
