<section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <span class="text-white">About Us</span>
          <h1 class="text-capitalize mb-5 text-lg">About Us</h1>

          <!-- <ul class="list-inline breadcumb-nav">
            <li class="list-inline-item"><a href="index.html" class="text-white">Home</a></li>
            <li class="list-inline-item"><span class="text-white">/</span></li>
            <li class="list-inline-item"><a href="#" class="text-white-50">About Us</a></li>
          </ul> -->
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section about-page">
	<div class="container">
		<div class="row">
			<div class="col-lg-4">
				<h2 class="title-color">What is organ donation and transplantation?</h2>
			</div>
			<div class="col-lg-8">
				<p>Organ donation is the process of surgically removing an organ or tissue from one person (the organ donor) and placing it into another person (the recipient). Transplantation is necessary because the recipient’s organ has failed or has been damaged by disease or injury.</p>
				<p>Organ transplantation is one of the great advances in modern medicine. Unfortunately, the need for organ donors is much greater than the number of people who actually donate. Every day in the United States, 21 people die waiting for an organ and more than 107,380 men, women and children await life-saving organ transplants.</p>
			</div>
		</div>
	</div>
</section>

<section class="fetaure-page ">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6">
				<div class="about-block-item mb-5 mb-lg-0">
					<img src="utilities/images/about/about-1.jpg" alt="" class="img-fluid w-100">
					<h4 class="mt-3">What organs and tissues can be transplanted?</h4>
					<p>Liver, Kidney, Pancreas, Heart, Lung, Intestine, Corneas, Middle ear, Skin, Bone, Bone marrow, Heart valves, Connective tissue.<a href="#">read more>></a></p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="about-block-item mb-5 mb-lg-0">
					<img src="utilities/images/about/about-2.jpg" alt="" class="img-fluid w-100">
					<h4 class="mt-3">Who can be an organ donor?</h4>
					<p>People of all ages should consider themselves potential donors. When a person dies, they are evaluated for donor suitability <a href="#">read more>></a></p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="about-block-item mb-5 mb-lg-0">
					<img src="utilities/images/about/about-3.jpg" alt="" class="img-fluid w-100">
					<h4 class="mt-3">Organ transplantation</h4>
					<p>Organ transplantation is a medical procedure where one organ removed from one person and placed in the body of recipient .	<a href="#">read more>></a></p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="about-block-item">
					<img src="utilities/images/about/about-4.jpg" alt="" class="img-fluid w-100">
					<h4 class="mt-3">Qualified Doctors</h4>
					<p>Voluptate aperiam esse possimus maxime repellendus, nihil quod accusantium .</p>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section awards">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-4">
				<h2 class="title-color">Our Partner Hospitals </h2>
				<div class="divider mt-4 mb-5 mb-lg-0"></div>
			</div>
			<div class="col-lg-8">
				<div class="row">
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/3.png" alt="" class="img-fluid">
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/4.png" alt="" class="img-fluid">
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/1.png" alt="" class="img-fluid">
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/2.png" alt="" class="img-fluid">
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/5.png" alt="" class="img-fluid">
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-6">
						<div class="award-img">
							<img src="utilities/images/about/6.png" alt="" class="img-fluid">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="section team">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="section-title text-center">
					<h2 class="mb-4">Celebrates words on organ donation</h2>
					<div class="divider mx-auto my-4"></div>
					<p>Celebrities has pledged to donate his organs after his death...</p>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block mb-5 mb-lg-0">
					
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/6YRdAtCZluY"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Akkineni Nagarjuna</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>

			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block mb-5 mb-lg-0">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/7r02EDdgJi4"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Chiranjeevi</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>

			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block mb-5 mb-lg-0">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/auv2GcLNzto"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Surya</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/WkDTZwqI3j4"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Farhan Akhtar</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/vfAoK0JIGDI"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Madhavan</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/oNT6fMKaCKs"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Garikipati Narasimha Rao</a></h4>
						<p>Orator, Avadhani and Author </p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/jIF5KovGo5c"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Narendra Modi</a></h4>
						<p>Prime Minister of India</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="team-block">
					<iframe class="img-fluid w-100" src="https://www.youtube.com/embed/xiCGSJaI-EU"></iframe>

					<div class="content">
						<h4 class="mt-4 mb-0"><a href="doctor-single.html">Vijay Deverakonda</a></h4>
						<p>Indian actor</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="section testimonial">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 offset-lg-6">
				<div class="section-title">
					<h2 class="mb-4">Who can be an organ donor?</h2>
					<div class="divider  my-4"></div>
				</div>
			</div>
		</div>
		<div class="row align-items-center">
			<div class="col-lg-6 testimonial-wrap offset-lg-6">
				<div class="testimonial-block">
					<div class="client-info ">
						<h4>Eligibility!</h4>
					</div>
					<p>
					Anyone can register a decision to become an organ donor after death, there is no age limit.To donate organs after death, a person needs to die in hospital in specific circumstances.Specialist healthcare professionals decide in each individual case whether a person's organs and tissue are suitable for donation. 
					</p>
					<i class="icofont-quote-right"></i>
					
				</div>

				<div class="testimonial-block">
					<div class="client-info">
						<h4>Age limit!</h4>
					</div>
					<p>
						There is no age limit for becoming an organ donor. It can be started at as young as six weeks. The decision about whether some or all organs or tissue are suitable for transplant is always made by medical specialists at the time of donation, taking into account your medical, travel and social history.
					</p>
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block">
					<div class="client-info">
						<h4>Medical conditions!</h4>
					</div>
					<p>
						Having an illness or medical condition doesn't necessarily prevent a person from becoming an organ or tissue donor. The decision about whether some or all organs or tissue are suitable for transplant is made by medical specialists at the time of donation, taking into account your medical, travel and social history.
					</p>
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block">
					<div class="client-info">
						<h4>Ethnicity!</h4>
					</div>
					<p>
						We need donors from all communities and ethnicities.<br><br>Blood and tissue types need to match for a transplant to be successful, and organs from donors of the same ethnic background as the recipient are more likely to be a close match.
					</p>
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block">
					<div class="client-info">
						<h4>Legal Framework in India!</h4>
					</div>
					<p>
						Transplantation of Human Organs Act (THOA) 1994 was enacted to provide a system of removal, storage and transplantation of human organs for therapeutic purposes and for the prevention of commercial dealings in human organs. THOA is now adopted by all States except Andhra and J&K .<a href="https://dghs.gov.in/content/1353_3_NationalOrganTransplantProgramme.aspx">more></a>
					</p>
					<i class="icofont-quote-right"></i>
				</div>
			</div>
		</div>
	</div>
</section>
