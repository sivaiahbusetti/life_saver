<!-- Slider Start -->
<section class="banner">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-12 col-xl-7">
				<div class="block">
					<div class="divider mb-3"></div>
					<span class="text-uppercase text-sm letter-spacing ">Donate life - Donate organ</span>
					<h1 class="mb-3 mt-3">Organ donation and Transplantation</h1>
					
					<p class="mb-4 pr-5">Organ donation and transplantation is removing an organ from one person (the donor) and surgically placing it in another (the recipient) whose organ has failed. Organs that can be donated include the liver, kidney, pancreas and heart.</p>
					<div class="btn-container ">
						<a href="<?php echo base_url();?>donation" target="_blank" class="btn btn-main-2 btn-icon btn-round-full">Make donation <i class="icofont-simple-right ml-2  "></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="features">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="feature-block d-lg-flex">
					<div class="feature-item mb-5 mb-lg-0">
						<div class="feature-icon mb-4">
							<i class="fa fa-heart orgicon" ></i>
						</div>
						<span>To Know About</span>
						<h4 class="mb-3">Organ donation</h4>
						<p class="mb-4">By registering to become an organ donor you have the option to donate organs such as your heart, lungs, liver, kidneys, pancreas, corneas, middle ear, skin, Bone, Bone marrow and small bowel.</p>
						<a href="<?php echo base_url();?>appoinment" class="btn btn-main btn-round-full">To Know More</a>
					</div>
				
					<div class="feature-item mb-5 mb-lg-0">
						<div class="feature-icon mb-4">
							<i class="icofont-surgeon-alt"></i>
						</div>
						<span>To Know About</span>
						<h4 class="mb-3">Organ transplantation</h4>
						<p class="mb-4">Organ transplantation is one of the great advances in modern medicine. Unfortunately, the need for organ donors is much greater than the number of people who actually donate.</p>
						<a href="<?php echo base_url();?>appoinment" class="btn btn-main btn-round-full">To Know More</a>
					</div>
				
					<div class="feature-item mb-5 mb-lg-0">
						<div class="feature-icon mb-4">
							<i class="icofont-support"></i>
						</div>
						<span>Emegency Help Desk</span>
						<h4 class="mb-3">1-800-700-6200</h4>
						<p>Get ALl time support for emergency.We have introduced the principle of family medicine.Get Conneted with us for any urgency .</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="section about">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-4 col-sm-6">
				<div class="about-img">
					<img src="utilities/images/about/img-1.jpg" alt="" class="img-fluid">
					<img src="utilities/images/about/img-2.jpg" alt="" class="img-fluid mt-4">
				</div>
			</div>
			<div class="col-lg-4 col-sm-6">
				<div class="about-img mt-4 mt-lg-0">
					<img src="utilities/images/about/img-3.jpg" alt="" class="img-fluid">
				</div>
			</div>
			<div class="col-lg-4">
				<div class="about-content pl-4 mt-4 mt-lg-0">
					<h2 class="title-color">Who can be an organ donor?</h2>
					<p class="mt-4 mb-5">People of all ages should consider themselves potential donors. When a person dies, they are evaluated for donor suitability based on their medical history and age. The organ procurement organization determines medical suitability for donation.</p>

					<a href="<?php echo base_url();?>about-us" class="btn btn-main-2 btn-round-full btn-icon">More<i class="icofont-simple-right ml-3"></i></a>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="cta-section ">
	<div class="container">
		<div class="cta position-relative">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="counter-stat">
						<i class="icofont-doctor"></i>
						<span class="h3">00</span>k
						<p>Happy People</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="counter-stat">
						<i class="icofont-flag"></i>
						<span class="h3">00</span>+
						<p>Transplantation Comepleted</p>
					</div>
				</div>
				
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="counter-stat">
						<i class="icofont-badge"></i>
						<span class="h3">00</span>+
						<p>Organ Donors</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="counter-stat">
						<i class="icofont-globe"></i>
						<span class="h3">00</span>
						<p>Awareness Programs</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="section appoinment gray-bg">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6 ">
				<div class="appoinment-content">
					<img src="utilities/images/about/img-3.jpg" alt="" class="img-fluid">
					<div class="emergency">
						<h2 class="text-lg"><i class="icofont-phone-circle text-lg"></i>+23 345 67980</h2>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">To register for organ recipients</h2>
					<p class="mb-4">register on the website with their essential information and request for login name.</p>
					
					<form name="myForm" class="appoinment-form" action="#" onsubmit="return validateForm()" method="post">
                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
                               <input name="name" id="fna" type="text" class="form-control" placeholder="Full Name">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect2">
                                  <option>Select Organ needed</option>
                                  <option>Heart</option>
                                  <option>Lungs</option>
                                  <option>Liver</option>
                                  <option>Kidneys</option>
                                  <option>Corneas</option>
                                  <option>Bone marrow</option>
                                  <option>Others</option>
                                </select>
                            </div>
                        </div>

                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="age" id="age" type="number" class="form-control" placeholder="Age">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <select class="form-control" id="blood">
                      				<option>select Blood Group</option>
                      				<option>A+</option>
                      				<option>A-</option>
                      				<option>B+</option>
                      				<option>B-</option>
                      				<option>O+</option>
         							<option>O-</option>
                      				<option>AB+</option>
                          			<option>AB-</option>
                          			<option>Other</option>
                          		</select>
                            </div>
                        </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="mail" id="mail" type="email" class="form-control" placeholder="Email address">
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <input name="mnum" id="mnum" type="number" class="form-control" placeholder="Phone Number">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                            	<label>Medical Certificate :</label>
                                <input name="file" id="file" type="file" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-main btn-round-full" value="submit">SUBMIT</button>
                </form>


		<script type="text/javascript">
			function validateForm()
          	{
          		var fna = document.getElementById("fna").value;
				var org = document.getElementById("exampleFormControlSelect2");
				var age = document.getElementById("age").value;
				var blood = document.getElementById("blood");
				var mail = document.getElementById("mail").value;
				var mnum = document.getElementById("mnum").value;
				var file = document.getElementById("file").required;

				
				
				if (fna == ""||fna =="null") 
          		{
          			alert("First Name can't be blank");
          			return false;
          		}
				if (org.selectedIndex == 0)
          		{
          			alert("Select Organ Type");
          			return false;
          		}
				if (age == ""||age =="null") 
          		{
          			alert("Age can't be blank");
          			return false;
          		}
				if (blood.selectedIndex == 0)
          		{
          			alert("Select blood Type");
          			return false;
          		}
				if (mnum == ""||mnum.length ==10) 
          		{
          			alert("mnum be blank");
          			return false;
          		}
				document.getElementById("file").innerHTML = file;
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.mail.value))
          		{
          			return (true)
          		}
          		else
          		{
          			alert("You have entered an invalid email address!");
          			return false;
          		}
				
				

			}
		</script>
            </div>
			</div>
		</div>
	</div>
</section>
<section class="section testimonial-2">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7">
				<div class="section-title text-center">
					<h2>We served over 0+ People</h2>
					<div class="divider mx-auto my-4"></div>
					<p>The recovery of organs, tissue and eyes is a surgical procedure performed by trained medical professionals. Generally, the family may still have a traditional funeral service.</p>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-12 testimonial-wrap-2">
				<div class="testimonial-block style-2  gray-bg">
					<i class="icofont-quote-right"></i>

					<div class="testimonial-thumb">
						<img src="utilities/images/team/test-thumb1.jpg" alt="" class="img-fluid">
					</div>

					<div class="client-info ">
						<h4>Amazing service!</h4>
						<span>John Partho</span>
						<p>
							They provide great service facilty consectetur adipisicing elit. Itaque rem, praesentium, iure, ipsum magnam deleniti a vel eos adipisci suscipit fugit placeat.
						</p>
					</div>
				</div>

				<div class="testimonial-block style-2  gray-bg">
					<div class="testimonial-thumb">
						<img src="utilities/images/team/test-thumb2.jpg" alt="" class="img-fluid">
					</div>

					<div class="client-info">
						<h4>Expert doctors!</h4>
						<span>Mullar Sarth</span>
						<p>
							They provide great service facilty consectetur adipisicing elit. Itaque rem, praesentium, iure, ipsum magnam deleniti a vel eos adipisci suscipit fugit placeat.
						</p>
					</div>
					
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block style-2  gray-bg">
					<div class="testimonial-thumb">
						<img src="utilities/images/team/test-thumb3.jpg" alt="" class="img-fluid">
					</div>

					<div class="client-info">
						<h4>Good Support!</h4>
						<span>Kolis Mullar</span>
						<p>
							They provide great service facilty consectetur adipisicing elit. Itaque rem, praesentium, iure, ipsum magnam deleniti a vel eos adipisci suscipit fugit placeat.
						</p>
					</div>
					
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block style-2  gray-bg">
					<div class="testimonial-thumb">
						<img src="utilities/images/team/test-thumb4.jpg" alt="" class="img-fluid">
					</div>

					<div class="client-info">
						<h4>Nice Environment!</h4>
						<span>Partho Sarothi</span>
						<p class="mt-4">
							They provide great service facilty consectetur adipisicing elit. Itaque rem, praesentium, iure, ipsum magnam deleniti a vel eos adipisci suscipit fugit placeat.
						</p>
					</div>
					<i class="icofont-quote-right"></i>
				</div>

				<div class="testimonial-block style-2  gray-bg">
					<div class="testimonial-thumb">
						<img src="utilities/images/team/test-thumb1.jpg" alt="" class="img-fluid">
					</div>

					<div class="client-info">
						<h4>Modern Service!</h4>
						<span>Kolis Mullar</span>
						<p>
							They provide great service facilty consectetur adipisicing elit. Itaque rem, praesentium, iure, ipsum magnam deleniti a vel eos adipisci suscipit fugit placeat.
						</p>
					</div>
					<i class="icofont-quote-right"></i>
				</div>
			</div>
		</div>
	</div>
</section>

