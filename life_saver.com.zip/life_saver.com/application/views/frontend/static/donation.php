<section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <span class="text-white">Make your </span>
          <h1 class="text-capitalize mb-5 text-lg">Donation</h1>

          <!-- <ul class="list-inline breadcumb-nav">
            <li class="list-inline-item"><a href="index.html" class="text-white">Home</a></li>
            <li class="list-inline-item"><span class="text-white">/</span></li>
            <li class="list-inline-item"><a href="#" class="text-white-50">Book your Seat</a></li>
          </ul> -->
        </div>
      </div>
    </div>
  </div>
</section>

<section class="appoinment section">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
          <div class="mt-3">
            <div class="feature-icon mb-3">
              <i class="icofont-support text-lg"></i>
            </div>
             <span class="h3">Call for an Emergency Service!</span>
              <h2 class="text-color mt-3">+84 789 1256 </h2>
          </div>
      </div>

      <div class="col-lg-8">
           <div class="appoinment-wrap mt-5 mt-lg-0 pl-lg-5">
            <h2 class="mb-2 title-color">Register for donation</h2>
            <p class="mb-4">By registering to become an organ donor you have the option to donate organs such as your heart, lungs, liver, kidneys, pancreas, corneas, middle ear, skin, Bone, Bone marrow and small bowel.</p>
            	<div class="untree_co-section">
    				<div class="container">
      					<div class="row">
        					<div class="col-lg-12 mb-5 mb-lg-0">
          						
								<form class="contact-form" data-aos="fade-up" data-aos-delay="200" name="myForm" action="<?php echo base_url();?>confirmation" onsubmit="return validateForm()" method="post">
            						<div class="row">
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="fname">First name</label>
                  								<input type="text" class="form-control" id="fname">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="lname">Last name</label>
                  								<input type="text" class="form-control" id="lname">
                							</div>
              							</div>
            						
                						<div class="col-6">
                    						<div class="form-group">
                      							<label class="text-black" for="blood_group">Blood Group</label>
                      							<select class="form-control" id="blood">
                      								<option>select...</option>
                      								<option>A+</option>
                      								<option>A-</option>
                      								<option>B+</option>
                      								<option>B-</option>
                      								<option>O+</option>
                      								<option>O-</option>
                      								<option>AB+</option>
                      								<option>AB-</option>
                      								<option>Other</option>
                      							</select>
                      						</div>
                						</div>
                						<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="age">Age</label>
                  								<input type="number" class="form-control" id="age">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="gender">Gender</label>
                  								<select class="form-control" id="gen">
                      								<option>select...</option>
                      								<option>Male</option>
                      								<option>Female</option>
                      								<option>Other</option>
                      							</select>
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="gender">Id</label>
                  								<input name="file" id="file" type="file" class="form-control">
                							</div>
              							</div>
              							<div class="col-12">
                							<div class="form-group">
                  								<label class="text-black" for="organ">Organs that I wish to donate</label>
                  								
                							</div>
              							</div>
              							<div class="col-12">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;all organs</div>
                							</div>
              							</div>
              							<div class="col-3">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;heart</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;lungs</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;liver</div>
                							</div>
              							</div>
              							<div class="col-3">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;kidneys</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;pancreas </div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;small bowel</div>
                							</div>
              							</div>
              							<div class="col-3">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Cornea(Eye)</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Tissue</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Bone</div>
                							</div>
              							</div>
              							<div class="col-3">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Pancreas</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Stomach</div>
                  								<div><input type="checkbox" id="" name="">&nbsp;&nbsp;Gallbladder</div>
                							</div>
              							</div>
              							<div class="col-12">
                							<div class="form-group">
                								<label>Address</label>
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">House/Flat Number</label>
                  								<input type="text" class="form-control" id="houseno">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">City</label>
                  								<input type="text" class="form-control" id="city">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">District</label>
                  								<input type="text" class="form-control" id="district">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">Pincode</label>
                  								<input type="number" class="form-control" id="pincode">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">State</label>
                  								<input type="text" class="form-control" id="state">
                							</div>
              							</div>
              							<div class="col-6">
                							<div class="form-group">
                  								<label class="text-black" for="">Country</label>
                  								<input type="text" class="form-control" id="country">
                							</div>
              							</div>
              							<div class="col-6">
                        					<div class="form-group">
                      							<label class="text-black" for="email">Email address</label>
                      							<input type="email" class="form-control" id="mail">
                    						</div>
                    					</div>
              							<div class="col-6">
                        					<div class="form-group">
                      							<label class="text-black" for="mobile">Mobile Number</label>
                      							<input type="number" class="form-control" id="mobnum">
                    						</div>
                    					</div>
                    					<div class="col-6">
                        					<div class="form-group">
                      							<label class="text-black" for="mobile">Alter Mobile Number</label>
                      							<input type="number" class="form-control" id="">
                    						</div>
                    					</div>
              							<div class="col-12">
                							<div class="form-group">
                  								<div><input type="checkbox" id="" name="">&nbsp;I aggri that donation of my organs after my death and has NO FINANCIAL REWARDS.</div>
                							</div>
              							</div>
              							
              							
              							
              							
              							
                					</div>
                					
            						

            						

            						<button type="submit" class="btn btn-primary" value="submit">SUBMIT</button>
            						<button type="reset" class="btn btn-primary" value="reset">RESET</button>
          						</form>
          						<script type="text/javascript">
          						
          						function validateForm()
          						{
          				  			var fname = document.getElementById("fname").value;
          							var lname = document.getElementById("lname").value;
          							var blood = document.getElementById("blood");
          							var age = document.getElementById("age").value;
          							var gen = document.getElementById("gen");
          							var houseno = document.getElementById("houseno").value;
          							var city = document.getElementById("city").value;
          							var district = document.getElementById("district").value;
          							var pincode = document.getElementById("pincode").value;
          							var state = document.getElementById("state").value;
          							var country = document.getElementById("country").value;
          							var mail = document.getElementById("mail").value;
          							var mobnum = document.getElementById("mobnum").value;
          							var file = document.getElementById("file").required;



          				


          				  			if (fname == ""||fname =="null") 
          							{
          				    				alert("First Name can't be blank");
          				    				return false;
          				  			}
          							if (lname == ""||lname =="null") 
          							{
          				    				alert("Last Name can't be blank");
          				    				return false;
          				  			}
          							if (blood.selectedIndex == 0)
          							{
          								alert("Select your blood group");
          				    				return false;
          							}
          							if (age == ""||age =="null") 
          							{
          				    				alert("Age can't be blank");
          				    				return false;
          				  			}
          							if (gen.selectedIndex == 0)
          							{
          								alert("Select your Gender");
          				    				return false;
          							}
          							document.getElementById("file").innerHTML = file;
          				  			if (houseno == ""||houseno =="null") 
          							{
          				    				alert("House Number can't be blank");
          				    				return false;
          				  			}
          							
          				  			if (city == ""||city =="null") 
          							{
          				    				alert("City can't be blank");
          				    				return false;
          				  			}
          							
          				  			if (district == ""||district =="null") 
          							{
          				    				alert("District can't be blank");
          				    				return false;
          				  			}
          							
          				  			if (pincode == ""||pincode.length==5) 
          							{
          				    				alert("Pincode can't be blank");
          				    				return false;
          				  			}
          							
          				  			if (state == ""||state =="null") 
          							{
          				    				alert("State can't be blank");
          				    				return false;
          				  			}
          							if (country == ""||country =="null") 
          							{
          				    				alert("Country can't be blank");
          				    				return false;
          				  			}
          							if (mobnum == ""||mobnum =="null") 
          							{
          				    				alert("Mobile Number can't be blank");
          				    				return false;
          				  			}
          							
          							if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.mail.value))
          				  			{
          				    				return (true)
          				  			}
          							else
          							{
          				    				alert("You have entered an invalid email address!")
          				    				return (false)
          							}
          						}
          					</script>
          					
        					</div>
        
      					</div>
    				</div>
  				</div>

           </div>
        </div>
      </div>
    </div>
  </div>
</section>
