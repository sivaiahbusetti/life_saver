<!DOCTYPE html>
<html lang="zxx">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Orbitor,business,company,agency,modern,bootstrap4,tech,software">
  <meta name="author" content="themefisher.com">

  <title>Life_saver.com</title>

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="utilities/images/favicon.ico" />

  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?php echo base_url();?>utilities/plugins/bootstrap/css/bootstrap.min.css">
  <!-- Icon Font Css -->
  <link rel="stylesheet" href="<?php echo base_url();?>utilities/plugins/icofont/icofont.min.css">
  <!-- Slick Slider  CSS -->
  <link rel="stylesheet" href="<?php echo base_url();?>utilities/plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="<?php echo base_url();?>utilities/plugins/slick-carousel/slick/slick-theme.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="utilities/css/style.css">

</head>

<body id="top">
<?php $this->view($layout);?>
 <!-- 
    Essential Scripts
    =====================================-->

    
    <!-- Main jQuery -->
    <script src="<?php echo base_url();?>utilities/plugins/jquery/jquery.js"></script>
    <!-- Bootstrap 4.3.2 -->
    <script src="<?php echo base_url();?>utilities/plugins/bootstrap/js/popper.js"></script>
    <script src="<?php echo base_url();?>utilities/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>utilities/plugins/counterup/jquery.easing.js"></script>
    <!-- Slick Slider -->
    <script src="<?php echo base_url();?>utilities/plugins/slick-carousel/slick/slick.min.js"></script>
    <!-- Counterup -->
    <script src="<?php echo base_url();?>utilities/plugins/counterup/jquery.waypoints.min.js"></script>
    
    <script src="<?php echo base_url();?>utilities/plugins/shuffle/shuffle.min.js"></script>
    <script src="<?php echo base_url();?>utilities/plugins/counterup/jquery.counterup.min.js"></script>
    <!-- Google Map -->
    <script src="<?php echo base_url();?>utilities/plugins/google-map/map.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkeLMlsiwzp6b3Gnaxd86lvakimwGA6UA&callback=initMap"></script>    
    
    <script src="<?php echo base_url();?>utilities/js/script.js"></script>
    <script src="<?php echo base_url();?>utilities/js/contact.js"></script>
	
	<!-- form validation -->
	<script type="text/javascript" src="utilities/js/validate.js"></script>
  </body>
  </html>