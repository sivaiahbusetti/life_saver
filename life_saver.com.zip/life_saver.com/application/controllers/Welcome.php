<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
    function general()
    {
        $data['layout'] 		= 'frontend/layout/layout';
        $data['header'] 		= 'frontend/layout/header';
        $data['banner']		    = 'frontend/layout/banner';
        $data['footer'] 		= 'frontend/layout/footer';
        return $data;
        
    }
	
	function index()
	{
	    $data = $this->general();
	    $data['pageName']  = "home";
	    $data['pageTitle'] 	= '';
	    $data['metaDesc']	= '';
	    $data['metaKey'] 	= '';
	    $data['content']   = "frontend/static/home";
		$this->load->view('frontend/welcome');
	}
	function about()
	{
	    $data = $this->general();
	    $data['pageName']  = "about";
	    $data['pageTitle'] 	= '';
	    $data['metaDesc']	= '';
	    $data['metaKey'] 	= '';
	    $data['content']   = "frontend/static/about";
	    $this->load->view('frontend/welcome',$data);
	}
	function service()
	{
	    $data = $this->general();
	    $data['pageName']  = "service";
	    $data['pageTitle'] 	= '';
	    $data['metaDesc']	= '';
	    $data['metaKey'] 	= '';
	    $data['content']   = "frontend/static/service";
	    $this->load->view('frontend/welcome',$data);
	}
}
