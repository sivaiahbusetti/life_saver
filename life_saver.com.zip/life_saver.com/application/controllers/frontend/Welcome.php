<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {
    function general()
    {
        $data['layout'] 		= 'frontend/layout/layout';
        $data['header'] 		= 'frontend/layout/header';
        $data['banner']		    = 'frontend/layout/banner';
        $data['footer'] 		= 'frontend/layout/footer';
        return $data;
        
    }
    function index()
    {
        $data = $this->general(); 
        $data['pageName']  = "home";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/home"; 
        $this->load->view('frontend/welcome',$data);
    }
    function about_us()
    {
        $data = $this->general();
        $data['pageName']  = "about_us";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/about";
        $this->load->view('frontend/welcome',$data);
    }
    function service()
    {
        $data = $this->general();
        $data['pageName']  = "service";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/service";
        $this->load->view('frontend/welcome',$data);
    }
    function department()
    {
        $data = $this->general();
        $data['pageName']  = "department";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/department";
        $this->load->view('frontend/welcome',$data);
    }
    function funds()
    {
        $data = $this->general();
        $data['pageName']  = "funds";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/funds";
        $this->load->view('frontend/welcome',$data);
    }
    function contacts()
    {
        $data = $this->general();
        $data['pageName']  = "contacts";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/contacts";
        $this->load->view('frontend/welcome',$data);
    }
    function donation()
    {
        $data = $this->general();
        $data['pageName']  = "donation";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/donation";
        $this->load->view('frontend/welcome',$data);
    }
    function confirmation()
    {
        $data = $this->general();
        $data['pageName']  = "confirmation";
        $data['pageTitle'] 	= '';
        $data['metaDesc']	= '';
        $data['metaKey'] 	= '';
        $data['content']   = "frontend/static/confirmation";
        $this->load->view('frontend/welcome',$data);
    }
}
?>
