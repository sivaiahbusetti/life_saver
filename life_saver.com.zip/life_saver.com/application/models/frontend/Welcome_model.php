<?php
class Welcome_model extends CI_Model
{
    function getbanners()
    {
        $this->db->select('*');
        $this->db->from('banners');
        $this->db->order_by("banner_id",'ASC');
        $query = $this->db->get();
        return $query->result();
    }
    
    //CONTACT US
    function addcontactusData($uname,$maile,$mobilephone,$subj,$mesage)
    {
        $updatedOn = date("Y-m-d");
        $updatedBy = $this->session->userdata('adminId');
        $createdOn = date("Y-m-d");
        $createdBy = $this->session->userdata('adminId');
        $insertArray = array(
            
            'name'          => ucwords($uname),
            'email'         => $maile,
            'phone_no'      => $mobilephone,
            'subject'       => $subj,
            'message'       => $mesage,
            'created_on'    => $createdOn,
            'updated_on'    => $updatedOn,
            'is_delete'     => 0
        );
        $this->db->insert('contact_us',$insertArray);
        return true;
    }
    //CONTACT US
}